<div>
![images](../Image/istockphoto-492499085-612x612.jpeg "Garrett A.Morgan")
</div>

<div id="Menu">

**Menu**

- [Accueil](index.html "page d'accueil")
- [Bibliographie](fichier1.html "page1")
- [Les inventions](fichier2.html "page2")
- [Vie Professionnelle](fichier3.html "page3")
- [Résumé historique](fichier4.html "page4")
- [Webographie](fichier5.html "page5")

</div>

<div id="titre">

**Titre**

# DecouvronsEnsemble

# Webographie

</div>

<div id="contenu">
| Les liens utilisés pour notre site web           |                              |
| ----------------------------------------------- | ---------------------------- |
| La Bibliographie                                 | La vie professionnelle       |
| - [La bibliographie](https://fr.wikipedia.org/wiki/Garrett_A._Morgan) | - [La mort et l'héritage](https://fr.swashvillage.org/article/garrett-morgan-biography-2) |

| Toutes les images de notre site web |
| ---------------------------------- |
| - [Images des brevets](https://www.grioo.com/ar,garrett_morgan_1877-1963_autodidacte_inventeur_et_homme_d_affaires,15279.html) |


- [la mort et l'héritage](https://fr.swashvillage.org/article/garrett-morgan-biography-2 )
- [Bibliographie](https://fr.wikipedia.org/wiki/Garrett_A._Morgan)
- [images des brevets](https://www.grioo.com/ar,garrett_morgan_1877-1963_autodidacte_inventeur_et_homme_d_affaires,15279.html)
</div>


<div id="auteurs"> Auteurs<i>

**Hoffer Kezia Beatrice et ONDONGI Gradi-Michael**

</div>
