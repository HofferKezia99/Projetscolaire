<div id="Menu">

**Menu**
- [Accueil](index.html "page d'accueil")
- [Bibliographie](fichier1.html "page1")
- [Les inventions](fichier2.html "page2")
- [Vie Professionnelle](fichier3.html "page3")
- [Résumé historique](fichier4.html "page4")
- [Webographie](fichier5.html "page5")


</div>

<div id="titre">

**Titre**
# Bibliographie:Garrett A.Morgan

</div>

<div id="contenu">

![images](../Image/garrett.jpeg "Garrett A.Morgan")

**Garrett A. Morgan** est né le 4 mars 1877 à Paris, Kentucky, dans une famille d'anciens esclaves. Il est le septième d'une famille de 11 enfants. Son éducation scolaire s'achève à l'âge de 14 ans ; moment où il quitte la maison et se déplace un peu. Il finit par se retrouver à Cleveland.
En 1901, **Garret A. Morgan** ouvre une boutique de vente et de réparation de machines à coudre où il crée sa première invention : un fermoir à sangle pour machines à coudre, qu'il vend pour 150 Dollars.

En 1909, Morgan travaillait avec des machines à coudre dans son atelier de couture nouvellement ouvert, une entreprise qu’il avait ouverte avec sa femme Mary. expérience en tant que couturière lorsqu’il a rencontré du tissu de laine qui avait été brûlé par une aiguille de machine à coudre. C'était un problème courant à l'époque, car les aiguilles de machine à coudre fonctionnaient à des vitesses aussi élevées. Dans l'espoir d'atténuer le problème, Morgan a expérimenté une solution chimique afin de réduire le frottement créé par l'aiguille et a par la suite remarqué que les poils du tissu étaient plus droits.
Après avoir essayé sa solution à bon escient sur un chien voisin'sa fourrure, **Morgan** a finalement testé le mélange sur lui-même. Quand cela a fonctionné, il a rapidement établi le **G.A. Morgan Hair Refining Company** et a vendu la crème à des Afro-Américains. La société a eu un succès incroyable, apportant la sécurité financière de Morgan et lui permettant de poursuivre d'autres intérêts.

En 1912, il crée le Safety Hood and Smoke Protector3 et dépose un brevet en 1914. Son système, simple, comportait un morceau de coton avec deux tuyaux qui pendaient et récoltaient l'air près du sol. Des éponges mouillées étaient insérées près de la sortie des tuyaux pour augmenter la qualité de l'air. Le premier prototype de masque a gaz a été inventé par Alexander von Humboldt en 1799.

Quand **Morgan** avait environ 25 ans, il a déménagé à Cincinnati, dans l'Ohio, pour chercher du travail, et l'a trouvé comme homme à tout faire pour un riche propriétaire terrien. Bien qu'il n'ait achevé que des études élémentaires, Morgan a été en mesure de payer davantage de leçons avec un tuteur privé. Mais des emplois dans plusieurs usines de machines à coudre vont bientôt captiver son imagination et déterminer son avenir. Apprenant le fonctionnement interne des machines et comment les réparer, Morgan a obtenu un brevet pour une machine à coudre améliorée et a ouvert son propre commerce de réparation.

Cette entreprise est un succès et lui permet d'épouser une femme bavaroise du nom de **Mary Anne Hassek** et de s'établir à Cleveland. (Lui et sa femme auraient trois fils pendant leur mariage.

En 1914, **Morgan** a breveté un appareil respiratoire, ou "cagoule de protection", offrant à ses porteurs une expérience de respiration plus sûre en présence de fumée, de gaz et d'autres polluants. Morgan a travaillé d'arrache-pied pour commercialiser l'appareil, en particulier auprès des services d'incendie, démontrant souvent personnellement sa fiabilité en cas d'incendie. Cet appareil respiratoire est devenu le prototype et le précurseur des masques à gaz utilisés pendant la Première Guerre mondiale, protégeant les soldats des gaz toxiques utilisés pendant la guerre. L’invention lui a valu le premier prix de la deuxième exposition internationale sur la sécurité et l’assainissement de New York.

Il y avait une certaine résistance à **Morgan's** dispositifs parmi les acheteurs, en particulier dans le Sud, où la tension raciale est restée palpable malgré les progrès des droits afro-américains. Dans le but de contrecarrer la résistance à ses produits, Morgan a engagé un acteur blanc pour se faire passer pour "l'inventeur" lors de la présentation de son appareil respiratoire; Morgan poserait en tant qu'inventeur'L’accompagnateur déguisé en Amérindien du nom de "Big Chief Mason" et, portant sa cagoule, pénètre dans des zones où il était difficile de respirer. La tactique a réussi. les ventes de l'appareil ont été rapides, notamment de la part des pompiers et des sauveteurs.

 **Garret A. Morgan** remporte la médaille d'or du First Grand Prize à la International Exposition of Safety and Sanitation (Exposition Internationale de la Sécurité et de la Santé publique) pour son masque à gaz.

1916 donne, à **Garret A. Morgan**, l'occasion de faire la démonstration de son masque à gaz. Il porte secours à de nombreux hommes bloqués sous le lac Érié, lors d'une explosion dans un tunnel à Cleveland.

La ville de Cleveland, Ohio, lui décerne une médaille d'or pour ses efforts héroïques.

Le masque de **Garret A. Morgan** servira également, lors de la Première Guerre mondiale, à protéger les soldats des vapeurs de gaz chloré.

**Garrett Morgan** a ouvert la voie aux inventeurs afro-américains avec ses brevets, notamment ceux d'un produit lissant les cheveux, d'un appareil respiratoire, d'une machine à coudre rénovée et d'un feu de signalisation amélioré.

</div>


<div id="auteurs"> Auteurs<i>

**Hoffer Kezia Beatrice et ONDONGI Gradi-Michael**

</div>
