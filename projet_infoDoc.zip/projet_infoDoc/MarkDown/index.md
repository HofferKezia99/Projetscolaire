<div id="Menu">

**Menu**
- [Accueil](index.html "page d'accueil")
- [Bibliographie](fichier1.html "page1")
- [Les inventions](fichier2.html "page2")
- [Vie Professionnelle](fichier3.html "page3")
- [Résumé historique](fichier4.html "page4")
- [Webographie](fichier5.html "page5")

</div>

<div id="titre">

**Titre**
# DecouvronsEnsemble
# Accueil:Les images illustrant Garrett A.Morgan

</div>

<div id="contenu">

![images](../Image/morgan1.jpeg "Garrett A.Morgan")
![images](../Image/morgan2.jpeg "Garrett A.Morgan")
![images](../Image/morgan3.jpeg "Garrett A.Morgan")
![images](../Image/morgan4.jpeg "Garrett A.Morgan")


<div id="auteurs">  Auteurs <i>

**Hoffer Kezia Beatrice et ONDONGI Gradi-Michael**

</div>
