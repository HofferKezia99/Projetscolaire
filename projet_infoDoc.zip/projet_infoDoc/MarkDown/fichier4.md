<div>
![images](../Image/istockphoto-492499085-612x612.jpeg "Garrett A.Morgan")
</div>

<div id="Menu">

**Menu**

- [Accueil](index.html "page d'accueil")
- [Bibliographie](fichier1.html "page1")
- [Les inventions](fichier2.html "page2")
- [Vie Professionnelle](fichier3.html "page3")
- [Résumé historique](fichier4.html "page4")
- [Webographie](fichier5.html "page5")


</div>

<div id="titre">

**Titre**

# DecouvronsEnsemble

# Résumé

</div>

<div id="contenu">


<p id= "dec1">

# Garrett Morgan – un inventeur qui a pris soin de ses cheveux


Garrett Morgan est né le **4 mars 1877** à Claysville (Kentucky). Il était le fils des anciens esclaves et il avait terminé six ans d’école primaire et à l’âge de 14 ans il est parti en Ohio pour chercher du travail. Il a rapidement trouvé un emploi de bricoleur, ce qui, d’une part, lui a permis d’acquérir une pratique complète et, d’autre part, lui a permis d’engager un enseignant et de poursuivre ses études. Après un certain temps, Morgan a déménagé à Cleveland pour réparer les machines à coudre. Dans l’usine où il travaillait, il a rencontré sa future épouse, Mary Hasek. Leur relation, en tant que mixte, n’a pas été acceptée et finalement ils ont été forcés de quitter leur emploi. Cet événement a donné une nouvelle tournure à sa carrière. Après un certain temps, ils ont ouvert conjointement le magasin de vêtements Morgan’s Cut Rate Ladies Clothing Store, où elle vendait des vêtements et lui, il s’occupait des réparations. L’expérience actuelle et les intérêts jusqu’à présent ont incité Morgan à travailler sur l’amélioration des machines, ce qui a abouti aux premières inventions. Parmi ses inventions il y avait un produit chimique pour la protection des aiguilles contre la surchauffe en permettant d’éviter d’endommager les tissus. Par coïncidence, l’inventeur a découvert que ce liquide était également idéal pour lisser les cheveux. Une autre société qu’il a fondée – G. A. Morgan Hair Refining Company – s’occupait de la distribution du liquide, et son propriétaire, au fil du temps, a élargi la gamme de produits, en ajoutant par exemple le colorant capillaire ou un peigne spécial pour lisser les cheveux.

Malgré sa carrière dans l’industrie cosmétique Morgan n’a pas abandonné son intérêt pour la technologie. Il convient d’accorder une attention particulière à ses réalisations dans le domaine des systèmes de sécurité. Il s’agit par exemple de la création de feux de signalisation automatiques. Ce n’était pas la première invention de ce type dans le monde, car de nombreux pays avaient essayé de résoudre le problème de la croissance du trafic routier de le réglementer au début du XXe siècle donc les travaux dans ce domaine ont été menés à divers endroits. Cependant l’idée de Morgan était tellement intéressante que General Electric a décidé d’acheter les droits de brevet. Ceci est important car dans les années suivantes, GE a presque complètement monopolisé le marché de la signalisation aux États-Unis, justement sur la base de ce projet.

Le capot de sécurité, qui peut être considéré comme un prototype du masque à gaz, était une autre invention importante de Morgan. Sa conception était simple – la hotte étanche avec les visières était équipé de tuyaux suspendus le long du corps et une éponge humide servait de filtre.

De cette manière, le pompier ou le mineur à qui cette hotte était destinée pouvait éviter le risque lié à la fumée ou aux gaz toxiques. Au fil du temps, l’armée s’est également intéressée à cette idée, et les versions modifiées de la hotte de Morgan ont été utilisées par les soldats pour sauver leur vie pendant la Première Guerre mondiale. Une autre société fondée par l’inventeur – National Safety Device Company s’est occupée de la production et des ventes. En présentant son produit, Morgan a lui-même mis sa hotte, puis est entré dans une tente enfumée pour montrer l’efficacité de l’appareil. Il faut ici mentionner un fait triste – pour éviter la controverse sur son origine et augmenter ses ventes, il a engagé souvent l’acteur blanc pour le remplacer en tant qu’inventeur.

Il convient également de mentionner les événements de juillet 1916, qui ont influencé l’avenir des hottes de Morgan. Il y a eu ensuite une explosion dans le tunnel sous le lac Érié. Les sauveteurs n’ont pas pu atteindre les victimes, et certains d’entre eux sont même morts. La situation a changé Morgan, qui est arrivé avec son frère. En utilisant les hottes, ils transportaient les victimes – ouvriers et sauveteurs – sur le dos. Cependant, malgré ses mérites et son héroïsme évidents, Morgan était toujours confronté à des préjugés raciaux – les autorités de Cleveland l’ont ignoré lors de la distribution des récompenses pour l’opération de sauvetage, ce qui n’a été rectifié que des années plus tard. Les médias, qui ont beaucoup écrit sur la tragédie, ont également ignoré les mérites de l’inventeur noir. De plus, les hottes sont devenues populaires, mais il y a eu des cas où des commandes ont été annulées lorsque les clients ont découvert que c’était Morgan les avait inventées.

![images](../Image/images.jpeg "Garrett A.Morgan")

Les difficultés auxquelles l’inventeur a été confronté ne l’ont pas empêché de poursuivre son objectif, de développer son entreprise et de lutter pour les droits de l’homme. Morgan a été l’un des fondateurs de l’organisation Cleveland Association of Coloured Men qui s’est transformée en National Association for the Advancement of Coloured People (NAACP). Il a également fondé un journal Cleveland Call et le club Wakeman Country Club qui était destiné uniquement aux Noirs.

Heureusement actuellement la discrimination raciale à laquelle Morgan a été confrontée est stigmatisée, ce qui est dans une certaine mesure également dû à l’inventeur américain et aux activités de l’organisation qu’il a aidée à créer. Pendant des années la conscience des risques auxquels sont exposés des employés des services mais également les employés des usines de production ou même des immeubles de bureaux, a augmenté. Le risque d’accidents comme celui dans lequel Morgan a montré son héroïsme est minimisé. La gamme de produits pour la protection de santé et de sécurité au travail comprend non seulement les équipements de protection respiratoire, mais aussi les équipements de protection de la tête et du visage, des mains et des mains et une large sélection de vêtements de protection, adaptés aux besoins et aux exigences de diverses industries.

Bien sûr, la sécurité des employés ne se limite pas aux équipements de protection individuelle. Actuellement, la plupart des immeubles de bureaux et parcs de machines utilisent, entre autres, les systèmes de contrôle d’accès, une large gamme de systèmes de sécurités d’installation et des milliers de capteurs et détecteurs, y compris les capteurs de gaz, y compris le CO2. Les postes de travail ou les zones dangereuses sont clairement signalés et sécurisés avec des bandes dédiées. Les installations du bâtiment sont constituées de matériaux sans halogène qui, en cas d’incendie, n’émettent pas de gaz toxiques, tandis que les appareils et composants destinés aux zones dangereuses doivent répondre aux exigences strictes de la directive ATEX.

Il convient de souligner que toutes ces protections ne sont qu’un élément supplémentaire des systèmes de sécurité et de protection de santé et de sécurité au travail. Le bon sens et les connaissances des employés sont toujours un facteur le plus important. La santé et la vie d’autrui peuvent dépendre du respect de l’environnement de travail, ainsi que d’une réaction rapide en cas de menace.
</p></div>


<div id="auteurs"> Auteurs<i>

**Hoffer Kezia Beatrice et ONDONGI Gradi-Michael**

</div>
