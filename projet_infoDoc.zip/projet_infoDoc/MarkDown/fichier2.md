<div id="Menu">

**Menu**
- [Accueil](index.html "page d'accueil")
- [Bibliographie](fichier1.html "page1")
- [Les inventions](fichier2.html "page2")
- [Vie Professionnelle](fichier3.html "page3")
- [Résumé historique](fichier4.html "page4")
- [Webographie](fichier5.html "page5")

</div>

<div id="titre">

**Titre**
# Les inventions

</div>

<div id="contenu">

![images](../Image/garrett2.jpeg "Garrett A.Morgan")![images](../Image/garrett3.jpeg "Garrett A.Morgan iventeurs ")
![images](../Image/garrett5.jpeg "Feux de signalisations")

Présent dans toutes les grandes villes du monde pour régler la circulation routière voire ferroviaire, le feu rouge est un de ces grands symboles de modernité du vingtième siècle. Précisement, ce que nous appelons communément "feu rouge", c'est-à-dire une signalisation routière automatique à trois positions (trois couleurs), a été mis au point en 1923 (brevet US n° 1,475,024).
Le feu rouge a souvent été signalé parmi les grandes inventions du vingtième siècle. *Garrett Morgan* vécut de ses inventions, en particulier il céda pour $ 40 000 de l'époque à la General Electric Company les droits de son brevet sur le feu rouge.
*Garrett Morgan* est un inventeur-né, un des plus grands inventeurs du début du vingtième siècle. L'humanité entière lui doit beaucoup. Dès 1912, mettant sa grande compétence en chimie au service de ses préoccupations humanitaires, il invente **le masque à gaz** dont le brevet US est déposé en 1914 (premier grand prix de la seconde exposition internationale d'hygiène et de séreté qui a eu lieu en 1914 aux U.S.A.) et a contribué à sauver tant de vies pendant la Première Guerre mondiale où le gaz a été utilisé pour la première fois comme une arme de destruction massive. Par la même occasion, il crée sa propre société pour l'exploitation commerciale de ses brevets d'invention.

L'efficacité du masque à gaz fut constaté en 1916 lors d'une explosion dans un tunnel de la station hydraulique de Cleveland. Grâce au masque à gaz, *Garrett Morgan* put sauver une vingtaine de travailleurs piégés à 75 mètres de profondeur sous le lac Erié, ce qui lui valut la médaille d'or pour héroïsme par la ville de Cleveland dans l'Ohio (ville où il s'est installé en 1895 et a effectué sa première invention en 1901). L'utilisation des sciences et de la technologie pour la protection des corps et des biens : tel semble avoir été le credo de *Garrett Morgan*, comme cela apparaît constamment dans ses inventions. Par sa conception technique d'emblée complète, **le feu rouge** de *Garrett Morgan* fait apparaître un triple souci humanitaire, économique et d'anticipation. En effet, le système est tout à la fois mécanique (utilisation de jour), électrique (utilisation de nuit) et sonore (pour les non-voyants) ; il est visible à distance et de tout point de l'intersection qu'il régule. **Le feu rouge**est devenu aujourd'hui l'un des éléments majeurs contribuant à la régulation des circulations automobile, ferroviaire et fluviale.


Les difficultés auxquelles l’inventeur a été confronté ne l’ont pas empêché de poursuivre son objectif, de développer son entreprise et de lutter pour les droits de l’homme. **Morgan** a été l’un des fondateurs de l’organisation Cleveland Association of Coloured Men qui s’est transformée en National Association for the Advancement of Coloured People (NAACP). Il a également fondé un journal Cleveland Call et le club Wakeman Country Club qui était destiné uniquement aux Noirs.

Heureusement actuellement la discrimination raciale à laquelle **Morgan** a été confrontée est stigmatisée, ce qui est dans une certaine mesure également dû à l’inventeur américain et aux activités de l’organisation qu’il a aidée à créer. Pendant des années la conscience des risques auxquels sont exposés des employés des services mais également les employés des usines de production ou même des immeubles de bureaux, a augmenté. Le risque d’accidents comme celui dans lequel **Morgan** a montré son héroïsme est minimisé. La gamme de produits pour la protection de santé et de sécurité au travail comprend non seulement les équipements de protection respiratoire, mais aussi les équipements de protection de la tête et du visage, des mains et des mains et une large sélection de vêtements de protection, adaptés aux besoins et aux exigences de diverses industries.

Bien sûr, la sécurité des employés ne se limite pas aux équipements de protection individuelle. Actuellement, la plupart des immeubles de bureaux et parcs de machines utilisent, entre autres, les systèmes de contrôle d’accès, une large gamme de systèmes de sécurités d’installation et des milliers de capteurs et détecteurs, y compris les capteurs de gaz, y compris le CO2. Les postes de travail ou les zones dangereuses sont clairement signalés et sécurisés avec des bandes dédiées. Les installations du bâtiment sont constituées de matériaux sans halogène qui, en cas d’incendie, n’émettent pas de gaz toxiques, tandis que les appareils et composants destinés aux zones dangereuses doivent répondre aux exigences strictes de la directive ATEX.

Il convient de souligner que toutes ces protections ne sont qu’un élément supplémentaire des systèmes de sécurité et de protection de santé et de sécurité au travail. Le bon sens et les connaissances des employés sont toujours un facteur le plus important. La santé et la vie d’autrui peuvent dépendre du respect de l’environnement de travail, ainsi que d’une réaction rapide en cas de menace.


![images](../Image/garrett4.jpg "Masque à gaz")


**Garrett Morgan** n'a pas été le seul inventeur Africain-Américain de son époque. Des inventeurs Africains-Américains dont l'histoire officielle a retenu les noms, il y en a eu beaucoup et de très grands même en pleine période d'esclavage, comme par exemple Elijah McCoy, Grandville T. Woods,



![images](../Image/brevet.jpg "Plaques commémoratives ")

![images](../Image/brevet1.gif "Brevet pour le système de signalisation ")

![images](../Image/brevet2.gif "Brevet pour le masque à gaz ")


[vidéo intéressante sur l'invention des Feux de signalisations par Garrett A.Morgan](https://www.youtube.com/watch?v=D8iTQGtv1a8 "cleveland 1923")

</div>


<div id="auteurs"> Auteurs<i>

**Hoffer Kezia Beatrice et ONDONGI Gradi-Michael**

</div>
