<div id="Menu">

**Menu**
- [Accueil](index.html "page d'accueil")
- [Bibliographie](fichier1.html "page1")
- [Les inventions](fichier2.html "page2")
- [Vie Professionnelle](fichier3.html "page3")
- [Résumé historique](fichier4.html "page4")
- [Webographie](fichier5.html "page5")


</div>

<div id="titre">

**Titre**
# cleveland tunnel Explosion et Activisme social

</div>

<div id="contenu">

En 1916, la ville de Cleveland forait un nouveau tunnel sous le lac Érié pour un approvisionnement en eau douce. Les travailleurs ont heurté une poche de gaz naturel, ce qui a provoqué une énorme explosion et emprisonné les travailleurs sous terre au milieu de poussières et de vapeurs nocives suffocantes. Lorsque Morgan a entendu parler de l'explosion, son frère et lui ont mis des appareils respiratoires, se sont dirigés vers le tunnel et sont entrés aussi rapidement que possible. Les frères ont réussi à sauver deux vies et à récupérer quatre corps avant la fin des opérations de secours..

En dépit de ses efforts héroïques, la publicité que **Morgan** a tirée de l’incident a nui aux ventes; le public était maintenant pleinement conscient du fait que **Morgan** était un Afro-américain et beaucoup ont refusé d'acheter ses produits. Ajoutant au détriment, ni l'inventeur ni son frère ne sont pleinement reconnus pour leurs efforts héroïques au lac Érié, probablement un autre effet de la discrimination raciale. Morgan a été nominé pour une médaille Carnegie pour ses efforts, mais n'a finalement pas été't choisi pour recevoir le prix. En outre, certains rapports sur l’explosion ont nommé d’autres les sauveteurs.

En dehors de sa carrière d'inventeur, **Morgan** a soutenu avec diligence la communauté afro-américaine tout au long de sa vie. Il était membre de l'Association nationale pour l'avancement des gens de couleur nouvellement formée, était actif au sein de l'association des hommes de couleur de Cleveland, avait fait don à des collèges nègres et avait ouvert un club de pays entièrement noir. De plus, en 1920, il lance le journal afro-américain, le Cleveland Call (plus tard nommé le Appeler et poster).

# La mort et l'héritage

**Morgan** a commencé à développer un glaucome en 1943 et a perdu la majeure partie de sa vue. L'inventeur accompli est décédé à Cleveland (Ohio) le 27 juillet 1963, peu de temps avant la célébration du centenaire de la Proclamation de l'émancipation, un événement qu'il attendait. Juste avant sa mort, Morgan a été honoré par le gouvernement américain pour son invention de signalisation routière. Il a finalement retrouvé sa place dans l’histoire en tant que héros de la rescousse du lac Érié..

**Morgan** a amélioré et sauvé d'innombrables vies dans le monde, y compris celles de pompiers, de soldats et de conducteurs de véhicules, grâce à ses inventions profondes. Ses travaux ont servi de base à de nombreux progrès importants qui ont été réalisés plus tard, et continuent d’inspirer et de servir de base aux recherches menées par les inventeurs et les ingénieurs modernes..

</div>


<div id="auteurs"> Auteurs<i>

**Hoffer Kezia Beatrice et ONDONGI Gradi-Michael**

</div>
